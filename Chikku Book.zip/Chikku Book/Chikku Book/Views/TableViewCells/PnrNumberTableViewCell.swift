//
//  PnrNumberTableViewCell.swift
//  Railway Reservation System
//
//  Created by shyam-15059 on 05/09/22.
//

import UIKit

class PnrNumberTableViewCell: UITableViewCell {

   
}
