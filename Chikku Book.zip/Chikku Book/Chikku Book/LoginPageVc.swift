//
//  LoginPageVc.swift
//  Railway Reservation System
//
//  Created by shyam-pt5397 on 26/07/22.
//

import UIKit

class LoginPageVc: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
//        view.backgroundColor = UIColor(red: 0, green: 178/255, blue: 85/255, alpha: 1)
//        let dbManager = DBManager.getInstance()
//
//        let ticketBooker = TicketCounter()
//        var passengerDetails = [PassengerDetailsInput]()
//        passengerDetails.append(PassengerDetailsInput(name: "Shyam", age: 22, gender: .Male, seatTypePreference: .Middle, preferredCoachNumber: "2"))
//
//        let ticket = ticketBooker.bookTickets(quotatype: .General, travelDate: Date(), fromStationCode: "MS", toStationCode: "TPJ", coachType: .SleeperClass, trainNumber: 12345, ticketNeeded: 1, passengerDetailsInputs: passengerDetails)
        
      //  print (ticket!.ticketStatus)
//        let ticketCounter = TicketCounter()
//        let dateFormatter = DateFormatter()
//        let travelDate = dateFormatter.toDate(format: "yyyy-MM-dd", string: "2022-08-03")
//        let values = ticketCounter.trainListForUserInput(quotatype: .General, travelDate: travelDate, fromStation: "Chennai Egmore", toStation: "Tiruchirappalli", coachType: .SleeperClass)
//        print(values)
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
